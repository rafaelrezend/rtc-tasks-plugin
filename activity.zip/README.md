Conditional BuildStep Plugin for Jenkins
========================================

Licensed under [MIT Licence].
 
About
-----
A buildstep wrapping any number of other buildsteps, controlling there execution based on a defined condition.
Requires TokenMacro Plugin (https://wiki.jenkins-ci.org/display/JENKINS/Token+Macro+Plugin) to be installed!

Wiki and Info
-------------
User documentation for the plugin can be found on the [wiki]

[wiki]: https://wiki.jenkins-ci.org/display/JENKINS/Conditional+BuildStep+Plugin



